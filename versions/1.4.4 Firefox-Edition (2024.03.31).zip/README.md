All details about the project and release v1.4.4 are publicly available on GitHub: https://github.com/niklas-englert/9GAG-Controls
